import React, { Component,useState } from "react";
import {Button, Modal} from 'antd'
// import { useHistory} from "react-router";

import "./start.css";

function StartContainer() {
    // let history = useHistory();
    const [agree, setAgree] = useState(false);
    const [text, setText] = useState("");
    const [answers, setAnswers] = useState({});
  
    const routeChange = (values) =>{ 
      console.log('Received values of form: ', values);
      let copySaveArray = values
      setAnswers(values)
      // save data
      let data = {
        user_id: localStorage.getItem("user-id"),
        text: text  // Include the inputted text in the data
      };
      sendData(data)
      let path = '/#/Instructions'; 
      // history.push(path);
      window.location.assign(path);
      console.log('moving to instructions page')
    }

    const onChangeInput = e => {
      setAgree(true);
      setText(e.target.value);
    };

    const sendData = (obj) => {
      fetch('http://localhost:8080/surveyData', {
        method: 'POST',
        body: JSON.stringify(obj),
        headers: {
          "Content-type": "application/json; charset=UTF-8"
        }
      }).then(response => response.json())
        .then(message => {
          console.log(message)
          // getLastestTodos();
        })
    }

    return (
      <div className="Home">
        <div className="lander">
            <h1>Reviewer.ly</h1>
            <p> Please enter a product URL </p>
        
            <div>
            <input
                    type="text"
                    value={text}
                    onChange={onChangeInput}
                />
            </div>

            <Button disabled={!agree} variant="btn btn-success" onClick={routeChange}>
                Continue
            </Button>
        </div>
      </div>
      );
}

export default StartContainer;