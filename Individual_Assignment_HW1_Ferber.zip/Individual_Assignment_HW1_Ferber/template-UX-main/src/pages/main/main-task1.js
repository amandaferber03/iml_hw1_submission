import React, { Component, useState, useEffect } from "react";
import { Button, Modal, Checkbox, Input, Radio } from "antd";
import "antd/dist/antd.css";
import "./main.css";
import PredictionContainer from "../../components/predictionContainer";


function Main1Container() {
 const [text, setText] = useState("");
 const [task, setTask] = useState(0);
 const [choice, setChoice] = useState(0);
 const [tmpUser, setTmpUser] = useState(0);
 const [imageData, setImageData] = useState([]);
 const [currentImage, setCurrentImage] = useState("");
 const [currentPrediction, setCurrentPrediction] = useState("");
 const [showPrediction1, setShowPrediction1] = useState(false);
 const [showPrediction2, setShowPrediction2] = useState(false);
 const [showPrediction3, setShowPrediction3] = useState(false);
 const [showPrediction4, setShowPrediction4] = useState(false);
 const [showPrediction5, setShowPrediction5] = useState(false);
 const [showPrediction6, setShowPrediction6] = useState(false);
 const [showPrediction7, setShowPrediction7] = useState(false);
 const [showPrediction8, setShowPrediction8] = useState(false);
 const [showPrediction9, setShowPrediction9] = useState(false);
 const [showPrediction10, setShowPrediction10] = useState(false);
 const [showPrediction11, setShowPrediction11] = useState(false);
 const [showPrediction12, setShowPrediction12] = useState(false);
 const [showPrediction13, setShowPrediction13] = useState(false);
 const [showPrediction14, setShowPrediction14] = useState(false);
 const [taskTime, setTaskTime] = useState(Date.now() + 1000 * 1000);
 const [currentTime, setCurrentTime] = useState(0);
 const [render, setRender] = useState(false);
 const [inputtedText, setStoredText] = useState("");
 const [productTitle, setProductTitle] = useState(
   "The Stanley Quencher H2.O Flowstate Tumbler"
 );
 const [imgFile, setImgFile] = useState("stanleytumbler.jpg");


 let totalImages = 3;
 const baseImgUrl = "./";


 const onChangeMultiple = (e) => {
   setChoice(e.target.value);
 };


 const onChangeInput = (e) => {
   setText(e.target.value);
 };


 const handlePredict1 = () => {
   setShowPrediction1(!showPrediction1);
 };


 const handlePredict2 = () => {
   setShowPrediction2(!showPrediction2);
 };


 const handlePredict3 = () => {
   setShowPrediction3(!showPrediction3);
 };


 const handlePredict4 = () => {
   setShowPrediction4(!showPrediction4);
 };


 const handlePredict5 = () => {
   setShowPrediction5(!showPrediction5);
 };


 const handlePredict6 = () => {
   setShowPrediction6(!showPrediction6);
 };


 const handlePredict7 = () => {
   setShowPrediction7(!showPrediction7);
 };


 const handlePredict8 = () => {
   setShowPrediction8(!showPrediction8);
 };


 const handlePredict9 = () => {
   setShowPrediction9(!showPrediction9);
 };


 const handlePredict10 = () => {
   setShowPrediction10(!showPrediction10);
 };


 const handlePredict11 = () => {
   setShowPrediction11(!showPrediction11);
 };


 const handlePredict12 = () => {
   setShowPrediction12(!showPrediction12);
 };


 const handlePredict13 = () => {
   setShowPrediction13(!showPrediction13);
 };


 const handlePredict14 = () => {
   setShowPrediction14(!showPrediction14);
 };


 // testing communication with backend
 useEffect(() => {
   fetch("http://0.0.0.0:8080/time")
     .then((res) => res.json())
     .then((data) => {
       setCurrentTime(data.time);
       console.log(data.time);
     });
 }, []);


 // create a new user here
 useEffect(() => {
   fetch("http://localhost:8080/setup_main")
     .then((response) => response.json())
     .then((data) => {
       console.log("Setup Main API Response:", data); // Log the entire response
       console.log("User ID:", data["user_id"]);
       setTask(data["task_number"]);
       // send user id as well
       setTmpUser(data["user_id"]);
     });
 }, []);


 // initialize image
 useEffect(() => {
    console.log("getting images");
    fetch("http://localhost:8080/imageInfo")
      .then((response) => response.json())
      .then((data) => {
        console.log(data["imgs"]);
        setImageData(data["imgs"]);
        let image_name = data["imgs"][0].name;
        setCurrentImage(image_name);
        console.log(image_name);
        setCurrentPrediction(data["imgs"][0].label);
        setRender(true);
        setTaskTime(Date.now());
      });
  }, []);
 

 useEffect(() => {
   // Fetch inputted text from the database using an API call
   fetchStoredText(tmpUser);
 }, [tmpUser]);


 const fetchStoredText = (user_id) => {
   // Make an API call to fetch the stored text from the database for the given user_id
   fetch(`http://localhost:8080/getSurveyData/${user_id}`, {
     method: "GET",
     headers: {
       "Content-type": "application/json; charset=UTF-8",
     },
   })
     .then((response) => {
       if (!response.ok) {
         throw new Error("Network response was not ok");
       }
       return response.json();
     })
     .then((data) => {
       // Check if data contains 'text' field
       if (data && data.text) {
         setStoredText(data.text); // Update storedText state with the fetched text
       } else {
         console.error("No survey data found for user_id", user_id);
       }
     })
     .catch((error) => {
       console.error("Error:", error);
     });
 };


 const openLink = () => {
   const urlRegex =
     /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;
   if (urlRegex.test(inputtedText)) {
     window.open(inputtedText, "_blank");
   } else {
     window.open(
       "https://www.stanley1913.com/products/adventure-quencher-travel-tumbler-40-oz?variant=44559722741887",
       "_blank"
     );
   }
 };


 useEffect(() => {
   if (inputtedText.startsWith("https:")) {
     // Find the index of the first "." in the URL
     const firstDotIndex = inputtedText.indexOf(".");
     // Find the index of the second "." in the URL, starting from the index after the first "."
     const secondDotIndex = inputtedText.indexOf(".", firstDotIndex + 1);
     // Extract the text between the first and second "." in the URL
     const extractedText = inputtedText.substring(
       firstDotIndex + 1,
       secondDotIndex
     );
     setProductTitle(extractedText + " product");
     setImgFile("productimage.jpeg");
   }
 }, [inputtedText]);


 return (
   <>
     {render && (
       <div className="container">
         <div className="title">Reviewer.ly</div>
         <div className="column-container">
           <div className="left-column">
             <div className="img-frame">
               <img className="image-inner" src={imgFile} />
             </div>
             <p>
               <u> {productTitle} </u> (4563 reviews)
             </p>
             <p>
               Overall reviewer score: <b>95 out of 100</b>{" "}
             </p>
             <Button className="btn-5" onClick={() => handlePredict1()}>
               How was the overall score calculated?
             </Button>
             {showPrediction1 && <PredictionContainer currentPrediction={1} />}
             <div style={{ marginTop: "40px" }}>
               <button onClick={openLink}>
                 Like what you see? Click here to buy product{" "}
               </button>
               <div style={{ marginTop: "40px" }}></div>
               <Button className="btn-5" onClick={() => handlePredict14()}>
                 General Information - How are these insights generated?
                 </Button>
                 {showPrediction14 && <PredictionContainer currentPrediction={14} />}
             </div>
           </div>


           <div className="right-column">
             <div className="instr">
             <p>
               <b>Overall Summary:</b>{" "} Despite minor drawbacks, most reviewers love the {productTitle}. If you’re looking for a durable, insulated tumbler with a large capacity, it’s a great option. However, it is not completely leak-proof or portable. 
             </p>
             <p> <b>Insights from review analysis</b></p>
               <Button className="btn-1" onClick={() => handlePredict2()}>
                 Features - Pros and Cons
               </Button>
               {showPrediction2 && <PredictionContainer currentPrediction={2} />}


               <Button className="btn-5" onClick={() => handlePredict3()}>
                 How are the Pros and Cons generated?
               </Button>
               {showPrediction3 && <PredictionContainer currentPrediction={3} />}
               <div style={{ marginTop: "40px" }}></div>
               <Button className="btn-1" onClick={() => handlePredict4()}>
                 Reliability
               </Button>
               {showPrediction4 && <PredictionContainer currentPrediction={4} />}
              
               <Button className="btn-5" onClick={() => handlePredict5()}>
                 How is reliability analyzed?
               </Button>
               {showPrediction5 && <PredictionContainer currentPrediction={5} />}
               <div style={{ marginTop: "40px" }}></div>
               <Button className="btn-1" onClick={() => handlePredict6()}>
                 Representative Reviews
               </Button>
               {showPrediction6 && <PredictionContainer currentPrediction={6} />}


               <Button className="btn-5" onClick={() => handlePredict7()}>
                 How were these reviews chosen?
               </Button>
               {showPrediction7 && <PredictionContainer currentPrediction={7} />}
               <div style={{ marginTop: "40px" }}></div>
               <Button className="btn-1" onClick={() => handlePredict8()}>
                 Exemplary User Images
               </Button>
               {showPrediction8 && <PredictionContainer currentPrediction={8} />}


               <Button className="btn-5" onClick={() => handlePredict9()}>
                 How were these images chosen?
               </Button>
               {showPrediction9 && <PredictionContainer currentPrediction={9} />}
               <div style={{ marginTop: "40px" }}></div>
               <Button className="btn-1" onClick={() => handlePredict10()}>
                 Common Sentiments
               </Button>
               {showPrediction10 && <PredictionContainer currentPrediction={10} />}


               <Button className="btn-5" onClick={() => handlePredict11()}>
                 How were these sentiments chosen?
               </Button>
               {showPrediction11 && <PredictionContainer currentPrediction={11} />}
               <div style={{ marginTop: "40px" }}></div>
               <p> <b>Insights about the reviews themselves</b></p>
               <Button className="btn-1" onClick={() => handlePredict12()}>
                 Review Credibility
               </Button>
               {showPrediction12 && <PredictionContainer currentPrediction={12} />}


               <Button className="btn-5" onClick={() => handlePredict13()}>
                 How do we estimate credibility?
               </Button>
               {showPrediction13 && <PredictionContainer currentPrediction={13} />}
             </div>
           </div>
         </div>
       </div>
     )}
   </>
 );
}


export default Main1Container;
