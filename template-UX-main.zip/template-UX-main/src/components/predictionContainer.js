import React, { useEffect, useState } from "react";
import './style.css'


// this is how you create a separate component
function PredictionContainer({ currentPrediction }) {
    // store the prediction message to display 

        const [predMessage, setPredMessage] = useState("");



    useEffect(() => {
        if (currentPrediction == 1) {
            setPredMessage("To calculate an overall product score from online reviews, we consider such as features, usability, and customer service ratings. Additionally, we conduct sentiment analysis to gauge the frequency and intensity of positive and negative sentiments expressed, considering metrics like sentiment polarity and sentiment intensity. This comprehensive analysis provides a quantitative measure of customer satisfaction, enabling consumers to make informed decisions based on both specific attributes and overall sentiment.")
        } else if (currentPrediction == 14) {
            setPredMessage("Large language models like GPT use deep learning to analyze product reviews, helping customers decide whether to purchase a product. They first learn language intricacies and are then fine-tuned to recognize sentiments and categorize reviews based on attributes like features or usability. By breaking down text into manageable units and understanding context, these models accurately capture nuances and sentiments. Customers can benefit from the models' ability to discern overall sentiments from reviews and generate summaries, aiding in their decision-making process when considering a purchase. Ultimately, these models empower customers by providing valuable insights from product reviews, helping them make informed decisions about buying products online.")
        } else if (currentPrediction == 3) {
            setPredMessage("For pros and cons, topics such as efficacy of features, perceived quality and durability, ease of use, visual and ergonomic design, usability, and consistency of performance were considered when analyzing reviews.")
        } else if (currentPrediction == 5) {
            setPredMessage("The top three weighted features for calculation of the reliability score are: references to longevity (25%), references to quality of materials (15%), and references relating to resilience (10%).")
        } else if (currentPrediction == 7) {
            setPredMessage("For representative quotes, excerpts that represent the ideas and sentiments of the entire body of quotes are selected. Topics such as customer loyalty, comparisons with competitors, emotional impact, and product improvement suggestions are considered when evaluating representativeness. ")
        } else if (currentPrediction == 9) {
            setPredMessage("We selected exemplary images from the user-provided images based on criteria including high quality, varied perspectives, feature focus, positive user experience, user interaction, and relevance to the review content, aiming to effectively showcase the product's key features and user experience to assist potential customers in making informed purchasing decisions.")
        } else if (currentPrediction == 11) {
            setPredMessage("Sentiments were extracted from thousands of product reviews using natural language processing techniques, analyzing the language used to express emotions such as satisfaction, disappointment, or praise. By employing sentiment analysis algorithms, key phrases, adjectives, and contextual clues were identified to gauge the overall sentiment towards the product, facilitating a comprehensive understanding of customer feedback.")
        } else if (currentPrediction == 13) {
            setPredMessage("Metrics for assessing the credibility of reviews for a product include the verified purchase ratio, standard deviation of ratings, review length analysis, sentiment consistency, reviewer reputation, response rate, and review recency. These metrics offer insights into factors such as the authenticity of reviewers, Credibility in opinions, depth of feedback, consistency in sentiment, reviewer reliability, engagement from product owners, and timeliness of reviews")
        } else if (currentPrediction == 2) {
            setPredMessage("Pros: Keeps drinks cold (or hot), stylish design, comfortable handle, durable build. Cons: Not fully leak-proof, cumbersome, dents quickly.")
        } else if (currentPrediction == 4) {
            setPredMessage("This product received a 91 (out of 100) for its reliability score. 7% of reviewers returned the product. 9% of reviews mentioning reliability have a negative sentiment. 4% of reviews reported slow shipping times.")
        } else if (currentPrediction == 6) {
            setPredMessage("Review 1: i really like my stanley but the one thing i wish they made the lid water proof so when i drop it or it tips over the water dont come spilling out but i like how cold it keeps the water. Review #2: The best cup I have ever owned. I have owned a few competitors but they dont match up to this beauty. Review #3: Love the size and feel, but it has design flaw with the lid cover...the “closed” position does not seal well...")
        } else if (currentPrediction == 8) {
            setPredMessage("Images loading")
        } else if (currentPrediction == 10) {
            setPredMessage("Satisfaction, Joy, Pride, Curiosity, Frustration, Annoyance")
        } else if (currentPrediction == 12) {
            setPredMessage("100% of reviewers awarded this product 4- or 5- star ratings. 32% of reviews may exhibit bias or exaggeration. 75% of reviews are written by women living in America.")
        }
    }, []);
    

    

    return (
        <div className="column-container">
            <div className="prediction-container">
                <div className="text"> 
                    <p> {predMessage}   </p>
                </div>
            </div> 
        </div>
    )
}

export default PredictionContainer;